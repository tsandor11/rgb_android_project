package brokerapp.rgbcolorchanges;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {


    int r = 0;
    int g = 0;
    int b = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        final SeekBar sb_red = (SeekBar)findViewById(R.id.seek1);
        final SeekBar sb_green = (SeekBar)findViewById(R.id.seek2);
        final SeekBar sb_blue = (SeekBar)findViewById(R.id.seek3);

        final TextView tw = (TextView)findViewById(R.id.textView);
        final TextView textvRed = (TextView)findViewById(R.id.r_txt);
        final TextView textvGreen = (TextView)findViewById(R.id.g_txt);
        final TextView textvBlue = (TextView)findViewById(R.id.b_txt);



        tw.setTextColor(Color.WHITE);
        tw.setText("RGB ("+r+","+g+","+b+")");

        sb_red.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                r = progress;
                textvRed.setText("Red : "+r);
                tw.setBackgroundColor(Color.rgb(r,g,b));
                tw.setTextColor(Color.WHITE);
                tw.setText("RGB ("+r+","+g+","+b+")");
                if(r == 255 && g == 255 && b == 255){
                    tw.setTextColor(Color.BLACK);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        sb_green.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                g = progress;
                textvGreen.setText("Green : "+g);
                tw.setBackgroundColor(Color.rgb(r,g,b));
                tw.setText("RGB ("+r+","+g+","+b+")");
                if(r == 255 && g == 255 && b == 255){
                    tw.setTextColor(Color.BLACK);
                }

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        sb_blue.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                b = progress;
                textvBlue.setText("Blue : "+b);
                tw.setBackgroundColor(Color.rgb(r,g,b));
                tw.setText("RGB ("+r+","+g+","+b+")");
                if(r == 255 && g == 255 && b == 255){
                    tw.setTextColor(Color.BLACK);
                }

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

    }


}
